using System.IO;
using System.Reflection.Metadata;
using System.Text;
namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        private StreamWriter New;
        private object otx;

        public object FBD { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Increment(-100);
            string otdtext = "Version 13 30\r\n{\r\n\t";
            string otdtextlast = ".otx\r\n}\r\n";
            string otxfirst = "Version 13 30\r\n{\r\n\tImage ";
            string otxlast = ".dds\r\n\tType Regular\r\n\tPixelFormat DXT5\r\n\tLevels 9\r\n\tUsage DIFFUSE\r\n\tUsageFlags FLAG_FULL\r\n\tExtraFlags 0\r\n}\r\n";



            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {

                listBox1.Items.Clear();
                string[] files = Directory.GetFiles(FBD.SelectedPath);
                string[] dirs = Directory.GetDirectories(FBD.SelectedPath);

                foreach (string file in files)
                {
                    listBox1.Items.Add(Path.GetFileName(file));


                    StreamWriter File = new(Path.GetDirectoryName(file) + "/" + Path.GetFileNameWithoutExtension(file) + ".otd");
                    File.Write(otdtext + Path.GetFileNameWithoutExtension(file) + otdtextlast);

                    File.Close();
                    StreamWriter File1 = new(Path.GetDirectoryName(file) + "/" + Path.GetFileNameWithoutExtension(file) + ".otx");
                    File1.Write(otxfirst + Path.GetFileNameWithoutExtension(file) + otxlast);

                    File1.Close();



                }


                foreach (string dir in dirs)
                {
                    listBox1.Items.Add(Path.GetFileName(dir));


                }

                progressBar1.Increment(100);


            }



        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamWriter File = new("meta.txt");
            File.Write("metaverse");


            File.Close();




        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
        }
    }
}